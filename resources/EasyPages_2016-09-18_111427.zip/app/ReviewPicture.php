<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReviewPicture extends Model {

	protected $table = 'r_pictures';
	public $timestamps = true;

}