<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServicePicture extends Model {

	protected $table = 's_pictures';
	public $timestamps = true;

}